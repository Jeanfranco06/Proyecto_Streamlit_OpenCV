import cv2
import numpy as np
import streamlit as st
from typing import Tuple, List, Optional

class ObjectTracker:
    """Clase para el seguimiento de objetos usando diversos métodos de OpenCV"""
    
    TRACKING_METHODS = {
        'CSRT': 'CSRT',
        'KCF': 'KCF',
        'MIL': 'MIL'
    }
    
    def __init__(self):
        self.tracker = None
        self.bbox = None
        self.tracking_method = 'CSRT'
        self.success = False
        
    def init_tracker(self, method: str):
        """Inicializa un nuevo tracker con el método especificado"""
        self.tracking_method = method
        if method == 'CSRT':
            self.tracker = cv2.legacy.TrackerCSRT_create()
        elif method == 'KCF':
            self.tracker = cv2.legacy.TrackerKCF_create()
        elif method == 'MIL':
            self.tracker = cv2.legacy.TrackerMIL_create()
        else:
            raise ValueError(f"Método de tracking desconocido: {method}")
        
    def start_tracking(self, frame: np.ndarray, bbox: Tuple[int, int, int, int]) -> bool:
        """Inicia el seguimiento de un objeto en el frame dado"""
        self.bbox = bbox
        return self.tracker.init(frame, bbox)
        
    def update_tracking(self, frame: np.ndarray) -> Tuple[bool, Optional[Tuple[int, int, int, int]]]:
        """Actualiza la posición del objeto en el nuevo frame"""
        if self.tracker is None:
            return False, None
        
        self.success, bbox = self.tracker.update(frame)
        if self.success:
            self.bbox = tuple(map(int, bbox))
        return self.success, self.bbox
        
    def draw_bbox(self, frame: np.ndarray) -> np.ndarray:
        """Dibuja el bounding box en el frame"""
        if self.success and self.bbox is not None:
            x, y, w, h = self.bbox
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(frame, f"Tracking: {self.tracking_method}", (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        return frame

def run():
    """
    Ejecuta el ejercicio de seguimiento de objetos en tiempo real usando Streamlit
    """
    st.title("Seguimiento de Objetos en Tiempo Real")
    st.write("""
    Este ejercicio demuestra el seguimiento de objetos en tiempo real usando diferentes algoritmos de OpenCV.
    
    Instrucciones:
    1. Selecciona un método de tracking
    2. Inicia la cámara
    3. Selecciona un objeto dibujando un rectángulo con el mouse
    4. Observa cómo el sistema sigue al objeto en tiempo real
    5. Puedes reiniciar la selección en cualquier momento
    """)

    # Selección del método de tracking
    tracking_method = st.selectbox(
        'Selecciona el método de tracking',
        list(ObjectTracker.TRACKING_METHODS.keys()),
        index=0
    )

    # Inicializar estados de la sesión
    if 'tracker' not in st.session_state:
        st.session_state.tracker = ObjectTracker()
        
    if 'selecting_roi' not in st.session_state:
        st.session_state.selecting_roi = False
        
    if 'camera_on' not in st.session_state:
        st.session_state.camera_on = False

    # Botón para reiniciar tracking
    if st.button('Reiniciar Tracking'):
        st.session_state.tracker = ObjectTracker()
        st.session_state.selecting_roi = True

    # Toggle para la cámara
    camera_on = st.toggle('Iniciar Cámara', st.session_state.camera_on)
    
    if camera_on:
        # Placeholder para el video
        video_placeholder = st.empty()
        
        # Capturar video de la cámara web
        cap = cv2.VideoCapture(0)
        
        try:
            while camera_on:
                ret, frame = cap.read()
                if not ret:
                    st.error("No se pudo acceder a la cámara web")
                    break
                
                # Si estamos seleccionando ROI
                if st.session_state.selecting_roi:
                    # Usar selectROI de OpenCV
                    bbox = cv2.selectROI("Selecciona el objeto a seguir", frame, False)
                    cv2.destroyWindow("Selecciona el objeto a seguir")
                    
                    # Iniciar tracking
                    st.session_state.tracker.init_tracker(tracking_method)
                    st.session_state.tracker.start_tracking(frame, bbox)
                    st.session_state.selecting_roi = False
                
                # Actualizar tracking
                success, bbox = st.session_state.tracker.update_tracking(frame)
                
                # Dibujar resultado
                frame = st.session_state.tracker.draw_bbox(frame)
                
                # Convertir de BGR a RGB para Streamlit
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                
                # Mostrar frame
                video_placeholder.image(frame_rgb, channels="RGB")
                
        except Exception as e:
            st.error(f"Error: {str(e)}")
            
        finally:
            cap.release()
            cv2.destroyAllWindows()
    
    st.session_state.camera_on = camera_on

if __name__ == '__main__':
    run()