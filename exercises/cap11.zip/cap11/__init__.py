"""
Capítulo 11: Seguimiento de Objetos en Tiempo Real
"""
